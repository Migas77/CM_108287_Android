---
name: Use nullability in Kotlin issue template
about: Issue template for Use nullability in Kotlin
title: 'Use nullability in Kotlin: Android Basics with Compose'
labels: ''
assignees: ''

---

**URL of codelab**


**In which task and step of the codelab can this issue be found?**


**Describe the problem**




**Steps to reproduce?**
1. Go to...
2. Click on...
3. See error...

**Versions**
_Android Studio version:_ 
_API version of the emulator:_ 


**Additional information**
_Include screenshots if they would be useful in clarifying the problem._
